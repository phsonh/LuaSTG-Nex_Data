collision_test_enemy = Class(object)

function collision_test_enemy:init()
    self.x = 192
    self.y = 224
    self.hp = 10

    self.group = GROUP_GHOST
    self.colli = false
    self.bound = false
    self.hide = true

    self.hurt_collider = Collision.addCollider(self, "enemy.hurt", {
        radius = 36,
    })

    Log(2, "[CollisionTest] enemy created, collider = " .. tostring(self.hurt_collider))
end

function collision_test_enemy:frame()
end

function collision_test_enemy:render()
end



collision_test_bullet = Class(object)

function collision_test_bullet:init()
    self.x = 192
    self.y = 224
    self.damage = 3

    self.group = GROUP_GHOST
    self.colli = false
    self.bound = false
    self.hide = true

    self.collider = Collision.addCollider(self, "player.bullet", {
        radius = 4,
    })

    Log(2, "[CollisionTest] bullet created, collider = " .. tostring(self.collider))
end

function collision_test_bullet:frame()
    if self.timer > 5 then
        Del(self)
    end
end

function collision_test_bullet:render()
end


function boss1(self)
    task.New(self,function ()
        task.Wait(90)
        local ang,x,fx = 0,0,0
        local dmk0 = danmaku:new()
        dmk0:set_type("grain_a",3)
        dmk0:set_num(1,1)
        dmk0:set_form("fan",0)
        dmk0:set_sound("kira00")
        dmk0:set_speed(3,1)
        while true do
            fx = ((-2/9)/2)*x + 14/3
            ang = ang + fx
            local count = 8
            for i=1, count do
                local theta = (i-1) * (360 / count)
                
                local a = ang + theta
                local offsetX, offsetY = 5 * cos(a), 5 * sin(a)
                
                --local b = New(bullet,"grain_a", 3, self.x + offsetX, self.y + offsetY, 3, a, 0, false)
                --local b_fog = bullet_mgr.bullet_effect.fog["grain_a"]
                --bullet_fog(b,3,25,b_fog.alpha.start_alpha,b_fog.alpha.tag_alpha,b_fog.scale.start_scale,b_fog.scale.tag_scale,b_fog.use_bullet_img)
                --bullet_fog(b,3,8,0,255,3,0.5,b_fog.use_bullet_img)
                dmk0:set_angle(a,0)
                dmk0:set_offset(offsetX,offsetY)
                dmk0:shoot(self)
            end
            x = x + 1
            task.Wait(2)
        end
        
    end)
end

collision_test_driver = Class(object)

function collision_test_driver:init()
    self.x = 0
    self.y = 0
    self.group = GROUP_GHOST
    self.colli = false
    self.bound = false
    self.hide = true

    assert(Collision, "Collision is nil")
    assert(Collision.addCollider, "Collision.addCollider is nil")
    assert(Collision.addRule, "Collision.addRule is nil")
    assert(Collision.update, "Collision.update is nil")

    Collision.reset()

    Collision.addRule("player.bullet", "enemy.hurt", function(bullet, enemy, bullet_collider, enemy_collider, profile_a, profile_b)
        enemy.hp = enemy.hp - (bullet.damage or 1)

        Log(2, string.format(
            "[CollisionTest] HIT! enemy.hp=%s bullet_collider=%s enemy_collider=%s profile=(%s,%s)",
            tostring(enemy.hp),
            tostring(bullet_collider),
            tostring(enemy_collider),
            tostring(profile_a),
            tostring(profile_b)
        ))

        Del(bullet)
    end)

    self.enemy = New(collision_test_enemy)
    self.bullet = New(collision_test_bullet)

    Log(2, "[CollisionTest] driver started")
end

function collision_test_driver:frame()
    local checks, hits = Collision.update()

    if self.timer % 30 == 0 then
        local stat = Collision.getStatistics()
        Log(2, string.format(
            "[CollisionTest] checks=%s hits=%s colliders=%s rules=%s",
            tostring(stat.checks),
            tostring(stat.hits),
            tostring(stat.colliders),
            tostring(stat.rules)
        ))
    end

    if self.timer > 120 then
        Log(2, "[CollisionTest] driver finished")
        Del(self)
    end
end

function collision_test_driver:render()
end